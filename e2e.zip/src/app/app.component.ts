import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { UserService } from './user.service'
import { HttpClient, HttpEventType, HttpRequest } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  providers:[UserService]
})
export class AppComponent implements OnInit{
  register;
  input;
  @ViewChild('file', { read: ElementRef })
  file: ElementRef;
constructor(private userService : UserService,
  private http: HttpClient
   ){}
  ngOnInit(){
    this.input ={
      username :'',
      email :'',
      password:''
    }
  }

  registerUser(){
    debugger;
    this.userService.registerNewUser(this.input).subscribe(
      response=>{
        alert('User '+this.input.username+' is Registered successfully')
      },
      error=>console.log('error',error)
    )
    
  }

  loginUser(){
    debugger;
    this.userService.loginNewUser(this.input).subscribe(
      response=>{
        alert('User '+this.input.username+' is Logged in successfully')
      },
      error=>console.log('error',error)
    )
    
  }

  ReadFileJson() {
    const files = (this.file.nativeElement as HTMLInputElement).files;

    const sendable = new FormData();
    sendable.append('documentTypeId', '302');

    let groups =  
      [{
        "typeId":"0",
        "instanceId":1,
      "keywords":[
        {"typeId":"1","value":"Test"},{"typeId":"290","value":""},{"typeId":"291","value":""},{"typeId":"121","value":""},{"typeId":"330","value":""},{"typeId":"237","value":""}
        ]
      }
      ];
      
      console.log(groups);
    sendable.append('keywordGroups', JSON.stringify(groups));
    for (let i = 0; i < files.length; i++) {
      sendable.append('files', files[i], files[i].name);
    }

    const request = new HttpRequest('POST',
      'http://127.0.0.1:8000/api/user_details/',
      sendable,
      {
        reportProgress: true
      });

    this.http.request(request)
      .subscribe((event: any) => {
        if (event.type === HttpEventType.UploadProgress) {
          // on progress code
        }
        if (event.type === HttpEventType.Response) {
          console.log(event);
          // on response code
        }
      }, error => {
        // on error code
      });
  }

}


