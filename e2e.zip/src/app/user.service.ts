import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http: HttpClient) { }

registerNewUser(userData):Observable<any> {
    return this.http.post('http://127.0.0.1:8000/api/users/', userData);
}

loginNewUser(userData):Observable<any> {
  return this.http.post('http://127.0.0.1:8000/api/auth/', userData);
}

// jsonLoad(userData):Observable<any> {
//   return this.http.post('http://127.0.0.1:8000/api/auth/', userData);
// }
}
